from tensorflow.keras.preprocessing.text import *

print(text_to_word_sequence("This is a dog."))
